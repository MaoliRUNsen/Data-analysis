# 　🐼 此文件夹为期末两项实践项目。

---

## 🕷项目一：前程无忧：51job数据分析


项目介绍：[点击跳转](https://gitee.com/Owenzhh/pandas_final/tree/master/Prj_51job)


## 🦠项目二：新冠肺炎疫情数据动态交互可视化(时空交互）

项目介绍：[点击跳转](https://gitee.com/Owenzhh/pandas_final/tree/master/Prj_Covid-19)






