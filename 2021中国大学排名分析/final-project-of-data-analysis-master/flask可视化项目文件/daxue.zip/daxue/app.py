
from flask import Flask, render_template, request
import pandas as pd
import cufflinks as cf
import plotly as py
import plotly.graph_objs as go


app = Flask(__name__)


# @app.route('/search4', methods=['POST'])
# def do_search() -> 'html':
#     phrase = request.form['phrase']
#     letters = request.form['letters']
#     title = 'Here are your results:'
#     results = str(search4letters(phrase, letters))
#     return render_template('results.html',
#                            the_title=title,
#                            the_phrase=phrase,
#                            the_letters=letters,
#                            the_results=results,)
#

df = pd.read_csv('C:/Users/喜东东/Desktop/daxue/中国大学综合排名2021.csv', encoding='gb2312')
类型名称 = list(df.类型.dropna().unique())
cf.set_config_file(offline=True, theme="ggplot")
py.offline.init_notebook_mode()


@app.route('/daxue',methods=['GET'])
def daxue_2021():
    data_str = df.to_html()
    return render_template('results2.html',
                           the_res = data_str,
                           the_select_type=类型名称)

@app.route('/daxue',methods=['POST'])
def daxue_select() -> 'html':
    the_type = request.form["the_type_selected"]
    print(the_type) # 检查用户输入
    dfs = df.query("类型=='{}'".format(the_type))
    df_summary = dfs.groupby("省市").agg({"学校名称":"count","总分":"mean"}).sort_values(by = "学校名称",ascending = False )
    print(df_summary.head(5)) # 在后台检查描述性统计
    ## user select
    # print(dfs)
    # 交互式可视化画图
    fig = dfs.iplot(kind="bar", x="省市", y="总分", asFigure=True)
    py.offline.plot(fig, filename="example.html",auto_open=False)
    with open("example.html", encoding="utf8", mode="r") as f:
        plot_all = "".join(f.readlines())

    # plotly.offline.plot(data, filename='file.html')
    data_str = dfs.to_html()
    return render_template('results2.html',
                            the_plot_all = plot_all,
                            the_res = data_str,
                            the_select_type=类型名称,
                           )



if __name__ == '__main__':
    app.run(debug=True)
